/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","ja",{button:"コードスニペットを挿入",codeContents:"コード内容",emptySnippetError:"コードスニペットを入力してください。",language:"言語",title:"コードスニペット",pathName:"コードスニペット"});