<?php

    return [
        'name'          =>  'IGD',
        'description'   =>  'Modul igd untuk KhanzaLITE',
        'author'        =>  'Basoro',
        'version'       =>  '1.0',
        'compatibility' =>  '2021',
        'icon'          =>  'ambulance',
        'install'       =>  function () use ($core) {

        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
