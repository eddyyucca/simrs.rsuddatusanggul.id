<?php
return [
    'name'          =>  'Profil',
    'description'   =>  'Modul profil',
    'author'        =>  'Basoro.ID',
    'version'       =>  '1.1',
    'compatibility' =>  '2021',
    'icon'          =>  'address-book'
];
