<?php

    return [
        'name'          =>  'Apotek Ralan',
        'description'   =>  'Modul apotek rawat jalan untuk KhanzaLITE',
        'author'        =>  'Basoro',
        'version'       =>  '1.0',
        'compatibility' =>  '2021',
        'icon'          =>  'shopping-cart',
    ];
