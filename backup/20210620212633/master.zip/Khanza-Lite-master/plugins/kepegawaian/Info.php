<?php
return [
    'name'          =>  'Kepegawaian',
    'description'   =>  'Pengelolaan data kepegawaian KhanzaLITE.',
    'author'        =>  'Basoro',
    'version'       =>  '1.1',
    'compatibility' =>  '2021',
    'icon'          =>  'group'
];
