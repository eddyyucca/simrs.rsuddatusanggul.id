<?php

return [
    'name'          =>  'ICD 9 - 10 Request',
    'description'   =>  'Modul ICD 9 - 10 untuk KhanzaLITE',
    'author'        =>  'Basoro',
    'version'       =>  '1.0',
    'compatibility' =>  '2021',
    'icon'          =>  'database'
];
