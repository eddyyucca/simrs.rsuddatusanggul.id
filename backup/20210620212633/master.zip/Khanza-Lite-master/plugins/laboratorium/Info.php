<?php

    return [
        'name'          =>  'Laboratorium',
        'description'   =>  'Modul Laboratorium untuk KhanzaLITE',
        'author'        =>  'Basoro',
        'version'       =>  '1.0',
        'compatibility' =>  '2021',
        'icon'          =>  'flask',
        'install'       =>  function () use ($core) {

        },
        'uninstall'     =>  function() use($core)
        {
        }
    ];
